[320 and Up](http://stuffandnonsense.co.uk/projects/320andup/)
=================

The ‘tiny screen first’ responsive boilerplate



This is the new ‘320 and Up’
----------------------------

Clone the repo, `git clone git@github.com:malarkey/320andup.git`, or [download the latest release](https://github.com/malarkey/320andup/zipball/master).

View [the project website](http://stuffandnonsense.co.uk/projects/320andup/) for more information.



CSS Preprocessor Options
------------------------

+ LESS
+ Sass
+ Sass + Compass
+ SCSS
+ SCSS + Compass



Authors
-------

**Andy Clarke**, main author, creator

+ http://twitter.com/malarkey
+ http://github.com/malarkey
+ http://stuffandnonsense.co.uk

**Jina Bolton**, Sass ports

+ http://twitter.com/jina
+ http://github.com/jina
+ http://sushiandrobots.com